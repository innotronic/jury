//
//  Jury
//  
//  Copyright::   (c) 2016 Innotronic Ingenieurbüro GmbH
//  URL::         www.inno.ch
//  Author::      Markus Meier
